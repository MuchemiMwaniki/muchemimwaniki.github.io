# Muchemi Mwaniki Portfolio

Welcome to my AI Prompt Engineering and Automation Portfolio.

## 🔧 What I Do
- ChatGPT/Claude Prompt Design
- AI + Automation with Zapier, N8N, and Gamma
- Local business workflows powered by AI
- Personalized customer service solutions

## 📫 Contact
- Email: muchemimwaniki@gmail.com
- WhatsApp: +254 773 053 465
- GitHub: [muchemimwaniki](https://github.com/muchemimwaniki)
